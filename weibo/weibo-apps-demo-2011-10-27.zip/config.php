<?php
header('Content-Type: text/html; charset=UTF-8');
define( "WB_AKEY" , 'xxxxxxxxx' );
define( "WB_SKEY" , 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx' );
define( "CANVAS_PAGE" , "http://apps.weibo.com/xxxxxxxx" );
