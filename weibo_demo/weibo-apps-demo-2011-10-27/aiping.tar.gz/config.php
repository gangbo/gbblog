<?php
header('Content-Type: text/html; charset=UTF-8');

define( "WB_AKEY" , '2975997035' );
define( "WB_SKEY" , '226690382bfd9c4ad77b0f9f7dfe8297' );
define( "CANVAS_PAGE" , "http://aiping.sinaapp.com" );
